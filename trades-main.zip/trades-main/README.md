# trades
my robots
